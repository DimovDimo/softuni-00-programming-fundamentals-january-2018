﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _00.Softuni_Workers
{
    class SoftuniWorkers
    {
        public int Opportunity { get; set; }
        public int Develpers { get; set; }
        public int QA { get; set; }
        public int Copywriters { get; set; }
        public int CountWorkers { get; set; }
        public decimal TotalDaySalary { get; set; }
    }
}
